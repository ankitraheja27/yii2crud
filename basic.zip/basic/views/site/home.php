<?php

use yii\helpers\html;

/* @var $this yii\web\View */

$this->title = 'Yii2 crud appplication';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1 style="color: #337ab7;">Yii2 Crud Application</h1>
   </div>

   <div class="row">
     <span style="margin-bottom: 20px;"><?= Html::a('Create', ['/site/create'], ['class'=> 'btn btn-primary'])?></span>
   </div>

    <div class="body-content">

        <div class="row">
            <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Title</th>
      <th scope="col">Description</th>
      <th scope="col">Category</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>

    <?php if(count($posts)>0): ?>

      <?php foreach($posts as $rows): ?>
    <tr class="table-active">
      <th scope="row"> <?php echo $rows->id; ?></th>
      <td><?php echo $rows->title; ?></td>
      <td><?php echo $rows->description; ?></td>
      <td><?php echo $rows->category; ?></td>
      <td>
        <span><?= Html::a('View')  ?></span>
       <span><?= Html::a('Update')  ?></span>
        <span><?= Html::a('Delete')  ?></span>
      </td>
    </tr>

  <?php endforeach; ?>


    <?php else: ?>

        <tr><td>NO record Found</td></tr>
     <?php endif; ?>
    
  </tbody>
</table>  
            
        </div>

    </div>
</div>
